HTTP API
========

.. automodule:: httpd
   :members:
   :undoc-members:
   :show-inheritance:
