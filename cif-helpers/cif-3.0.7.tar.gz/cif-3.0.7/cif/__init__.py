
from ._version import get_versions
VERSION = get_versions()['version']
del get_versions
